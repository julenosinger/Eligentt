﻿MULTICALL FIX - Maximum call stack size exceeded

Correções aplicadas:
1. Não trava mais em "empty returnData" na simulação (comportamento normal no Arc)
2. Proteção (try/catch) em torno de batchTx.wait(), finalizeBatch() e refreshBalance()
3. Aviso quando o batch é muito grande (>150 recipients) — encoding grande pode causar stack overflow em alguns browsers

Recomendação: Para batches com >150 recipients, use o botão "Execute in Parts".

Use o arquivo INSTRUCOES-DEPLOY.txt para subir no Cloudflare.
