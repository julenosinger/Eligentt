﻿ELLIGENTE - CORRIGIDO (Simulation Multicall3)

Versão com correção para o erro "simulation_failed: empty returnData".

MUDANÇA PRINCIPAL:
- Quando o Multicall3 retorna apenas "empty returnData" (comportamento comum no Arc Testnet),
  o app NÃO bloqueia mais a transação.
- A proteção real agora vem das simulações diretas no token (provider.call) que rodam antes.

Use a wallet 0xccda8a39... para testar.

Siga as INSTRUCOES-DEPLOY.txt para subir no Cloudflare.
