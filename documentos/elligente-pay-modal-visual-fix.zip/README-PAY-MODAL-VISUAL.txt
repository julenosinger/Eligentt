﻿ELLIGENTE - PAY MODAL VISUAL FIX

Fixed the issue where clicking "Open payment page" in the Payments section
showed the ELLIGENTE PAY modal broken (no proper shape/background) and
overlapping the menu incorrectly.

Changes (isolated to this modal only):
- Added full, modern CSS for .pay-modal-overlay + .pay-modal when open.
- Proper dark backdrop, centered card with good border-radius and shadow.
- High z-index (999999) so it appears above the sidebar/menu.
- Clean header, amount display, details, QR section, and action buttons.
- The modal now opens with correct visual "forma".

No other part of the application was modified.

Deploy and hard refresh (Ctrl+Shift+R).
