﻿ELLIGENTE - MULTISEND FIX (Balance decode error resolved)

Correcao aplicada: Usamos agora JsonRpcProvider fresco para leituras de balanceOf e allowance no fluxo de Multisend.
Isso evita o erro 'could not decode result data (value=0x)' para balanceOf.

O modal continua no tamanho compacto ideal que voce aprovou.
