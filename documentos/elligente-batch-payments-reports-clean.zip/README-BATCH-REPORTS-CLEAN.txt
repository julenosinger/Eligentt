﻿ELLIGENTE - BATCH PAYMENTS CLEAN + REPORTS ENABLED

Changes in this version (minimal and isolated):

- Removed "ElligentBatch Contract" and "Cross-Chain Batcher (Arc → Others)" configuration sections from the Batch Payments page.
  (Contracts are now hardcoded in the JS code - edit the constants at the top of the script or in DEPLOYED section).

- Reports page is now explicitly enabled on navigation and will capture batch / crosschain / transaction data created in the app.

No other changes. All logic, contracts, HTML structure (except the two removed sections), buttons, and flows remain exactly the same.

Deploy as usual via Direct Upload.
