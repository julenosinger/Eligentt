﻿ELLIGENTE - RESTORED VERSION (Before Send Assets Page Work)

This version has the Send Assets page (HTML + JS + CSS) completely removed.

The "Send" button in the Batch Payments page has been reverted to open the original Single Send modal.

All changes related to the "Send Assets" page have been reverted to restore stability.

Multisend and the rest of the app should be back to the state before the Send page was introduced.
