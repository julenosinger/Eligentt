﻿ELLIGENTE - PAY MODAL COMPLETELY HIDDEN FROM LAYOUT

This version adds multiple layers of protection so the "ELLIGENTE PAY" box
never appears in the normal page flow or below the footer.

Changes:
- Extremely strong CSS (multiple rules with !important + position offscreen)
- Inline style on the element itself
- JavaScript safety net on DOMContentLoaded
- Updated open/close functions that force the strongest hiding styles

The modal will ONLY become visible when openPayLanding() is called (i.e. when previewing a Payment Link).

All functionality preserved. No other part of the app was modified.
