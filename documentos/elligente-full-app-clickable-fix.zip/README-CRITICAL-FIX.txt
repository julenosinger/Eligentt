﻿ELLIGENTE - CRITICAL CLICKABILITY FIX

This version fixes the major issue where the entire app became unclickable (menu, wallet connect, CSV upload in Multisend, etc.).

Root cause:
- A global override of the showPage() function was added for the Send page and was breaking the whole application.

Fix applied:
- Removed the dangerous window.showPage override.
- Integrated the Send page refresh safely inside the original showPage() function (same pattern already used for 'reports', 'pool', 'swap').

All previous improvements to the Send Assets page (better UI, support for USDC/EURC/cirBTC) are preserved.

Multisend and all other features should now work normally again.

Deploy this ZIP.
