﻿ELLIGENTE - PAY MODAL MORE COMPACT

Further reduced size of the ELLIGENTE PAY modal (when opening "Open payment page" from Payments section):

- Max-width reduced from 440px to 380px
- Smaller paddings, fonts, logo, buttons, and QR (now 120px)
- Still looks clean and professional, but takes less screen space

All other functionality untouched.
