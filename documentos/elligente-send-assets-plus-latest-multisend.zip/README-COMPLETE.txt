﻿ELLIGENTE - SEND ASSETS PAGE + LATEST MULTISEND FIXES

This version combines:

✓ The new "Send Assets" page (compact professional UI, supports USDC + EURC + cirBTC)
✓ All the latest Multisend robustness fixes developed in this session:
  - Fresh JsonRpcProvider for balanceOf checks (fixes decode 0x errors)
  - Safe handling of empty returnData in Multicall3 simulation
  - Protections against "Maximum call stack size exceeded" on large batches
  - Contract addresses now hardcoded in code (UI config sections removed from Batch page)
  - Reports page properly refreshes and captures data

The "Send" button in Batch Payments now opens the new Send Assets page.
The "Batch" button continues to work as before.

No other features were modified.
