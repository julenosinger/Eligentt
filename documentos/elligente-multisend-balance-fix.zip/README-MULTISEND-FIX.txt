﻿ELLIGENTE - MULTISEND BALANCE DECODE FIX

Correção aplicada:
- Troquei a leitura de balanceOf no fluxo do Multisend para usar um JsonRpcProvider fresco (https://rpc.testnet.arc.network) em vez do signer.
- Isso resolve o erro recorrente "could not decode result data (value=0x)" para balanceOf.

Nenhuma outra mudança foi feita no Multisend, contratos, lógica de execução, etc.

Use este ZIP para deploy.
