﻿ELLIGENTE - INBOUND ARC CCTP FIX

Root cause: The special 'robust' polling code for inbound to Arc (domain 26) was using unreliable direct /attestations/{hash} + hardcoded /v2/messages/0 fallback instead of the proper V2 endpoint with the actual source domain.

Fix: Both inbound-to-Arc paths now use the same reliable Iris V2 polling as outbound/other routes (with high patience for Arc sandbox).

No other code paths were modified. Arc outbound (from Arc) and all other features are untouched.
