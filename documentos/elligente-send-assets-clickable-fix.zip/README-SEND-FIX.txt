﻿ELLIGENTE - SEND PAGE FIX (Clickable buttons)

- Fixed clickability issues on the Send Assets page by using proper addEventListener instead of inline onclick.
- Added wallet connection guard before sending.
- Improved error handling and button states.
- Better support for USDC / EURC / cirBTC selection.

Multisend and all other pages were NOT modified.

Deploy this version.
