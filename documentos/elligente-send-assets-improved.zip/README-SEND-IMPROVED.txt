﻿ELLIGENTE - IMPROVED SEND ASSETS PAGE

- Modern, clean, premium UI for the Send page (isolated CSS)
- Full support for sending USDC, EURC and cirBTC
- Better asset cards, route preview, and layout
- Direct transfer support on Arc Testnet for the three assets
- Does NOT touch Multisend, Batch, Bridge, or any other logic

Deploy normally.
