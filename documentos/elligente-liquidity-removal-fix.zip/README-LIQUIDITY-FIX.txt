﻿ELLIGENTE - LIQUIDITY REMOVAL FIX (only this flow changed)

Root cause:
- In executeRemoveLiquidity(), the code was doing:
  const pc = new ethers.Contract(POOL_CONTRACT_ADDRESS, POOL_CONTRACT_ABI, signer);
  await pc.approve(...)

- But POOL_CONTRACT_ABI does NOT contain the "approve" function (it only has pool-specific methods + balanceOf/totalSupply).

Fix applied:
- For the LP token approval step, we now create the contract instance using the standard USDC_ABI (which contains approve).
- Added the requested validation, logging of addresses + ABI functions.
- Improved error messages.
- The removeLiquidity call still uses the original POOL_CONTRACT_ABI (correct).

Only the remove liquidity function was modified.
All other functionality (add liquidity, swap, multisend, bridge, etc.) is untouched.
