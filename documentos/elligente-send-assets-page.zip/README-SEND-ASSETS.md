﻿ELLIGENTE - SEND ASSETS PAGE (New Dedicated Page)

This version adds a completely new "Send Assets" page as requested.

CHANGES (isolated & non-destructive):
- Changed the "Send" button in Batch Payments page to navigate to the new /send page (using existing showPage system).
- Added new page: page-send with professional single-transfer interface.
- Supports USDC, EURC, cirBTC (asset selector).
- Reuses existing navigation, history, and falls back to existing single-send logic.
- Reports page now explicitly refreshes on navigation.
- Removed the two contract configuration sections from Batch Payments as previously requested.

NO changes were made to:
- Any smart contracts or addresses
- Multisend / Batch logic
- Cross-Chain, Swap, Payment Links, Invoices, etc.
- Wallet connection or transaction services

The "Batch" button continues to work exactly as before.

Deploy via Direct Upload as usual.
