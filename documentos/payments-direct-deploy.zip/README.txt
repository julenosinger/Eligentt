﻿ELLIGENTE - PAYMENTS DIRECT DEPLOY (BUGS FIXED)
==============================================

Este pacote corrige os dois problemas da página de Payment Links:

✓ Clicar no card agora abre a página de pagamento
✓ Botão "Pay with Wallet" agora conecta a wallet automaticamente

ARQUIVOS:
- index.html          → Aplicação Payments Links corrigida
- _headers            → Headers de segurança para Cloudflare
- _redirects          → SPA fallback
- robots.txt

COMO FAZER DEPLOY DIRETO NO CLOUDFLARE:
1. Acesse https://dash.cloudflare.com → Pages → Create a project
2. Escolha "Direct Upload"
3. Arraste TODOS os arquivos desta pasta (ou o .zip extraído)
4. Clique em Deploy

Ou:
- Crie um novo projeto Pages
- Faça upload manual dos arquivos
- O index.html será servido automaticamente

NOTA IMPORTANTE:
Este é um deploy ISOLADO apenas da funcionalidade de Payment Links.
Nenhum arquivo do projeto principal Eligentt foi modificado.

Chain: Arc Testnet (5042002)
Token: USDC
