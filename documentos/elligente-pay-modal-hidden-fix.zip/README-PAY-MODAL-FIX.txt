﻿ELLIGENTE - PAY LANDING MODAL HIDDEN FIX

Problem: The "ELLIGENTE PAY" confirmation modal (used for Payment Links) was rendering visibly below the footer because its hiding CSS was missing or weak.

Fix applied:
- Added strong CSS rules (with !important) to force .pay-modal-overlay to be hidden by default.
- Added inline style="display:none !important;" on the overlay element.
- Updated openPayLanding() and closePayLanding() to explicitly control display style in addition to the .open class.

Functionality is 100% preserved — the modal will still appear correctly when a Payment Link or Invoice is opened for payment.

All other parts of the site untouched.
