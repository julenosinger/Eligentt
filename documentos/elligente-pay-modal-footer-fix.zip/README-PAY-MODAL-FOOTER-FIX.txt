﻿ELLIGENTE - FIX: ELLIGENTE PAY modal no longer appears below the footer

Changes (minimal and non-destructive):
- Added very strong CSS rules (with !important) to force the pay-landing-overlay to stay hidden.
- Added inline style with !important directly on the element.
- Updated the open/close JS functions to explicitly control the inline style.

The modal will ONLY appear when a Payment Link or Invoice is actively opened for payment.
All functionality remains 100% intact.

Deploy this ZIP and do a hard refresh (Ctrl+Shift+R).
