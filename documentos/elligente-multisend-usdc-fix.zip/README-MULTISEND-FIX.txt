﻿ELLIGENTE - MULTISEND FIX (usdcContract is not defined)

Correção:
- Restaurada a declaração correta de usdcContract e eurcContract com signer (necessárias para approve e execução).
- Mantida a leitura de balance usando JsonRpcProvider fresco para evitar o erro de decode.

O Multisend agora deve funcionar sem o erro "usdcContract is not defined".

Use este ZIP.
